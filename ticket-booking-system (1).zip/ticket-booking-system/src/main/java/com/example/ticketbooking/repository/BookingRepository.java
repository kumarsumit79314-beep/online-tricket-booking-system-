package com.example.ticketbooking.repository;

import com.example.ticketbooking.model.Booking;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class BookingRepository {
    private final JdbcTemplate jdbc;
    public BookingRepository(JdbcTemplate jdbc){this.jdbc=jdbc;}
    public List<Booking> findAll(){
        return jdbc.query("SELECT b.*,e.title AS event_title FROM bookings b JOIN events e ON e.id=b.event_id ORDER BY b.created_at DESC",
            (rs,n)->new Booking(rs.getLong("id"),rs.getLong("user_id"),rs.getLong("event_id"),rs.getString("event_title"),
            rs.getInt("quantity"),rs.getBigDecimal("total_price"),rs.getString("booking_code"),rs.getString("status")));
    }
    public List<Booking> findByUser(long userId){
        return jdbc.query("SELECT b.*,e.title AS event_title FROM bookings b JOIN events e ON e.id=b.event_id WHERE b.user_id=? ORDER BY b.created_at DESC",
            (rs,n)->new Booking(rs.getLong("id"),rs.getLong("user_id"),rs.getLong("event_id"),rs.getString("event_title"),
            rs.getInt("quantity"),rs.getBigDecimal("total_price"),rs.getString("booking_code"),rs.getString("status")),userId);
    }
}
