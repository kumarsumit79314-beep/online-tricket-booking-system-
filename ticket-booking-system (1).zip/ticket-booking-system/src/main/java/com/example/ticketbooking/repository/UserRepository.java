package com.example.ticketbooking.repository;

import com.example.ticketbooking.model.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public class UserRepository {
    private final JdbcTemplate jdbc;
    public UserRepository(JdbcTemplate jdbc){this.jdbc=jdbc;}

    public Optional<User> findByEmail(String email) {
        return jdbc.query("SELECT * FROM users WHERE email=?", rs ->
            rs.next() ? Optional.of(new User(rs.getLong("id"), rs.getString("name"), rs.getString("email"),
                rs.getString("password_hash"), rs.getString("role"))) : Optional.empty(), email);
    }
    public long create(String name, String email, String passwordHash) {
        jdbc.update("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'USER')", name, email, passwordHash);
        return jdbc.queryForObject("SELECT id FROM users WHERE email=?", Long.class, email);
    }
}
