package com.example.ticketbooking.model;

import java.math.BigDecimal;

public class Booking {
    private long id, eventId, userId;
    private String eventTitle, bookingCode, status;
    private int quantity;
    private BigDecimal totalPrice;

    public Booking(long id, long userId, long eventId, String eventTitle, int quantity,
                   BigDecimal totalPrice, String bookingCode, String status) {
        this.id=id; this.userId=userId; this.eventId=eventId; this.eventTitle=eventTitle;
        this.quantity=quantity; this.totalPrice=totalPrice; this.bookingCode=bookingCode; this.status=status;
    }
    public long getId(){return id;} public long getUserId(){return userId;} public long getEventId(){return eventId;}
    public String getEventTitle(){return eventTitle;} public int getQuantity(){return quantity;}
    public BigDecimal getTotalPrice(){return totalPrice;} public String getBookingCode(){return bookingCode;}
    public String getStatus(){return status;}
}
