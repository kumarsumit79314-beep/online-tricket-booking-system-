package com.example.ticketbooking.service;

import com.example.ticketbooking.exception.BookingException;
import com.example.ticketbooking.model.Booking;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.UUID;

@Service
public class StandardBookingService implements BookingOperations {
    private final JdbcTemplate jdbc;
    public StandardBookingService(JdbcTemplate jdbc){this.jdbc=jdbc;}

    @Override
    @Transactional
    public synchronized Booking book(long userId, long eventId, int quantity) {
        if(quantity < 1 || quantity > 10) throw new BookingException("Choose between 1 and 10 tickets.");
        var events = jdbc.query("SELECT * FROM events WHERE id=? FOR UPDATE", (rs,n)->new Object[]{
            rs.getString("title"),rs.getBigDecimal("price"),rs.getInt("available_seats")}, eventId);
        if(events.isEmpty()) throw new BookingException("Event not found.");
        Object[] event=events.get(0);
        int available=(Integer)event[2];
        if(available < quantity) throw new BookingException("Not enough seats are available.");
        BigDecimal total=((BigDecimal)event[1]).multiply(BigDecimal.valueOf(quantity));
        jdbc.update("UPDATE events SET available_seats=available_seats-? WHERE id=?",quantity,eventId);
        String code="TB-"+UUID.randomUUID().toString().substring(0,8).toUpperCase();
        jdbc.update("INSERT INTO bookings(user_id,event_id,quantity,total_price,booking_code,status) VALUES(?,?,?,?,?,'CONFIRMED')",
            userId,eventId,quantity,total,code);
        Long id=jdbc.queryForObject("SELECT id FROM bookings WHERE booking_code=?",Long.class,code);
        return new Booking(id,userId,eventId,(String)event[0],quantity,total,code,"CONFIRMED");
    }
}
