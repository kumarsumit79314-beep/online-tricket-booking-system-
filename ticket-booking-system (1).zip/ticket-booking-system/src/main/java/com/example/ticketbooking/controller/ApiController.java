package com.example.ticketbooking.controller;

import com.example.ticketbooking.exception.BookingException;
import com.example.ticketbooking.repository.EventRepository;
import com.example.ticketbooking.repository.BookingRepository;
import com.example.ticketbooking.service.AuthService;
import com.example.ticketbooking.service.BookingOperations;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ApiController {
    private final EventRepository events;
    private final BookingRepository bookings;
    private final AuthService auth;
    private final BookingOperations bookingService;

    public ApiController(EventRepository events, BookingRepository bookings, AuthService auth, BookingOperations bookingService){
        this.events=events;this.bookings=bookings;this.auth=auth;this.bookingService=bookingService;
    }

    @GetMapping("/events") public Object events(){return events.findAll();}
    @PostMapping("/register") public Object register(@RequestBody Map<String,String> body){
        try{return auth.register(body.get("name"),body.get("email"),body.get("password"));}
        catch(IllegalArgumentException e){throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());}
    }
    @PostMapping("/login") public Object login(@RequestBody Map<String,String> body){
        try{return auth.login(body.get("email"),body.get("password"));}
        catch(IllegalArgumentException e){throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,e.getMessage());}
    }
    @PostMapping("/bookings") public Object book(@RequestBody Map<String,Object> body){
        try{
            long userId=Long.parseLong(body.get("userId").toString());
            long eventId=Long.parseLong(body.get("eventId").toString());
            int quantity=Integer.parseInt(body.get("quantity").toString());
            return bookingService.book(userId,eventId,quantity);
        }catch(BookingException|IllegalArgumentException e){throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());}
    }
    @GetMapping("/users/{id}/bookings") public Object myBookings(@PathVariable long id){return bookings.findByUser(id);}
    @GetMapping("/admin/bookings") public Object allBookings(){return bookings.findAll();}
    @PostMapping("/admin/events") public Object addEvent(@RequestBody Map<String,Object> b){
        try{
            events.add(b.get("title").toString(),b.get("category").toString(),b.get("venue").toString(),
                b.get("eventDate").toString(),Double.parseDouble(b.get("price").toString()),
                Integer.parseInt(b.get("availableSeats").toString()),String.valueOf(b.getOrDefault("description","")));
            return Map.of("message","Event added successfully.");
        }catch(DataAccessException|IllegalArgumentException e){throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Could not add event. Check the fields and date.");}
    }
    @DeleteMapping("/admin/events/{id}") public Object deleteEvent(@PathVariable long id){
        if(events.delete(id)==0) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Event not found.");
        return Map.of("message","Event deleted.");
    }
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Map<String,String> handleUnexpected(Exception e){return Map.of("error","Something went wrong. Check the server log.");}
}
