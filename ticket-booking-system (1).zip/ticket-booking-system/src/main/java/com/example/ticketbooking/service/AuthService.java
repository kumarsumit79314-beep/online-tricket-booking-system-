package com.example.ticketbooking.service;

import com.example.ticketbooking.model.User;
import com.example.ticketbooking.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Map;

@Service
public class AuthService {
    private final UserRepository users;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    public AuthService(UserRepository users){this.users=users;}

    public Map<String,Object> register(String name,String email,String password){
        if(name==null||name.isBlank()||email==null||!email.contains("@")||password==null||password.length()<6)
            throw new IllegalArgumentException("Enter a name, valid email and password of at least 6 characters.");
        if(users.findByEmail(email).isPresent()) throw new IllegalArgumentException("This email is already registered.");
        long id=users.create(name.trim(),email.trim().toLowerCase(),encoder.encode(password));
        return Map.of("id",id,"name",name.trim(),"email",email.trim().toLowerCase(),"role","USER");
    }
    public Map<String,Object> login(String email,String password){
        User u=users.findByEmail(email==null?"":email.trim().toLowerCase()).orElseThrow(()->new IllegalArgumentException("Invalid email or password."));
        if(!encoder.matches(password==null?"":password,u.getPasswordHash())) throw new IllegalArgumentException("Invalid email or password.");
        return Map.of("id",u.getId(),"name",u.getName(),"email",u.getEmail(),"role",u.getRole());
    }
}
