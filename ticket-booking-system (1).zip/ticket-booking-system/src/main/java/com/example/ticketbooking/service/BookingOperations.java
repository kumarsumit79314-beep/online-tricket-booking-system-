package com.example.ticketbooking.service;

import com.example.ticketbooking.model.Booking;

public interface BookingOperations {
    Booking book(long userId, long eventId, int quantity);
}
