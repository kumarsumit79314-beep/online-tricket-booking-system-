package com.example.ticketbooking.repository;

import com.example.ticketbooking.model.Event;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class EventRepository {
    private final JdbcTemplate jdbc;
    public EventRepository(JdbcTemplate jdbc){this.jdbc=jdbc;}
    public List<Event> findAll(){
        return jdbc.query("SELECT * FROM events ORDER BY event_date", (rs,n)->new Event(
            rs.getLong("id"),rs.getString("title"),rs.getString("category"),rs.getString("venue"),
            rs.getDate("event_date").toLocalDate(),rs.getBigDecimal("price"),rs.getInt("available_seats"),
            rs.getString("description")));
    }
    public Event findById(long id){
        return jdbc.query("SELECT * FROM events WHERE id=?", rs -> rs.next()?new Event(
            rs.getLong("id"),rs.getString("title"),rs.getString("category"),rs.getString("venue"),
            rs.getDate("event_date").toLocalDate(),rs.getBigDecimal("price"),rs.getInt("available_seats"),
            rs.getString("description")):null,id);
    }
    public int add(String title,String category,String venue,String date, double price,int seats,String description){
        return jdbc.update("INSERT INTO events(title,category,venue,event_date,price,available_seats,description) VALUES(?,?,?,?,?,?,?)",
            title,category,venue,date,price,seats,description);
    }
    public int delete(long id){return jdbc.update("DELETE FROM events WHERE id=?",id);}
}
