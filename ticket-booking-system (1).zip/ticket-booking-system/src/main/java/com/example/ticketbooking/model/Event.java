package com.example.ticketbooking.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Event {
    private long id;
    private String title, category, venue, description;
    private LocalDate eventDate;
    private BigDecimal price;
    private int availableSeats;

    public Event(long id, String title, String category, String venue, LocalDate eventDate,
                 BigDecimal price, int availableSeats, String description) {
        this.id=id; this.title=title; this.category=category; this.venue=venue;
        this.eventDate=eventDate; this.price=price; this.availableSeats=availableSeats; this.description=description;
    }
    public long getId(){return id;} public String getTitle(){return title;}
    public String getCategory(){return category;} public String getVenue(){return venue;}
    public LocalDate getEventDate(){return eventDate;} public BigDecimal getPrice(){return price;}
    public int getAvailableSeats(){return availableSeats;} public String getDescription(){return description;}
}
