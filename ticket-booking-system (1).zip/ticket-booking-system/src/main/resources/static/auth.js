let mode='login';
function showAuth(next){mode=next;document.getElementById('loginTab').classList.toggle('active',mode==='login');document.getElementById('registerTab').classList.toggle('active',mode==='register');document.getElementById('nameWrap').classList.toggle('hidden',mode!=='register');document.getElementById('name').required=mode==='register';document.getElementById('submitAuth').innerHTML=(mode==='login'?'Login':'Create account')+' <span>→</span>';document.getElementById('authMessage').textContent='';}
document.getElementById('authForm').addEventListener('submit',async e=>{
 e.preventDefault();const msg=document.getElementById('authMessage');msg.textContent='Please wait…';
 const body={email:document.getElementById('email').value,password:document.getElementById('password').value};
 if(mode==='register')body.name=document.getElementById('name').value;
 try{const r=await fetch('/api/'+(mode==='login'?'login':'register'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw new Error(data.message||'Unable to continue.');
 localStorage.setItem('ticketlyUser',JSON.stringify(data));msg.style.color='#247340';msg.textContent='Success! Redirecting…';
 if(data.role==='ADMIN')location.href='/admin.html';else location.href='/';
 }catch(err){msg.style.color='#b43e2a';msg.textContent=err.message}
});
