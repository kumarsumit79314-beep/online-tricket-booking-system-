let currentUser = null;
const $ = id => document.getElementById(id);
function toast(message){const t=$('toast');t.textContent=message;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)}
async function api(url, options={}) {
  const res=await fetch(url,{headers:{'Content-Type':'application/json',...(options.headers||{})},...options});
  const data=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.message||data.error||'Request failed. Please try again.');
  return data;
}
function safe(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function loadEvents(){
 try{
  const events=await api('/api/events');
  $('eventsGrid').innerHTML=events.length?events.map((e,i)=>`<article class="event-card"><div class="event-cover c${i%3+1}"><span class="cover-symbol">${['♫','✳','☻'][i%3]}</span><span class="category">${safe(e.category)}</span></div><div class="event-info"><h3>${safe(e.title)}</h3><p>⌖ ${safe(e.venue)}</p><p>◷ ${safe(e.eventDate)} · ${e.availableSeats} seats left</p><p>${safe(e.description||'A memorable live experience.')}</p><div class="event-foot"><span class="price">₹${Number(e.price).toLocaleString('en-IN')} <small>/ ticket</small></span><button class="small-btn" onclick="bookEvent(${e.id})">Book tickets ↗</button></div></div></article>`).join(''):'<p class="muted">No events yet. Please check back soon.</p>';
 }catch(e){$('eventsGrid').innerHTML='<p class="muted">Could not load events. Check that the Java server and MySQL are running.</p>'}
}
async function bookEvent(eventId){
 const raw=localStorage.getItem('ticketlyUser');
 if(!raw){location.href='/login.html';return}
 const quantity=Number(prompt('How many tickets? (1–10)','1'));
 if(!Number.isInteger(quantity)||quantity<1||quantity>10)return;
 try{const b=await api('/api/bookings',{method:'POST',body:JSON.stringify({userId:JSON.parse(raw).id,eventId,quantity})});toast('Booking confirmed! Code: '+b.bookingCode);loadEvents();loadMyBookings()}
 catch(e){toast(e.message)}
}
async function loadMyBookings(){
 const raw=localStorage.getItem('ticketlyUser');if(!raw)return;
 const user=JSON.parse(raw);
 try{const bs=await api('/api/users/'+user.id+'/bookings');
 $('myBookings').innerHTML=bs.length?bs.map(b=>`<div class="booking-row"><div><strong>${safe(b.eventTitle)}</strong><small>Code: ${safe(b.bookingCode)} · ${b.quantity} ticket(s) · ₹${Number(b.totalPrice).toLocaleString('en-IN')}</small></div><span class="status">${safe(b.status)}</span></div>`).join(''):'<p class="muted">You have no bookings yet. Explore the events above.</p>'}
 catch(e){$('myBookings').innerHTML='<p class="muted">Could not load bookings.</p>'}
}
document.addEventListener('DOMContentLoaded',()=>{document.body.classList.add('reveal-ready');document.querySelectorAll('.section-heading,.event-grid,.booking-list').forEach(el=>el.classList.add('reveal'));if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-visible');observer.unobserve(entry.target)}}),{threshold:.12});document.querySelectorAll('.reveal').forEach(el=>observer.observe(el))}else{document.querySelectorAll('.reveal').forEach(el=>el.classList.add('is-visible'))}loadEvents();loadMyBookings()});
