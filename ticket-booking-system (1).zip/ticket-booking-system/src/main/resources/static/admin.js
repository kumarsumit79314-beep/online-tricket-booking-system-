const $=id=>document.getElementById(id);
function safe(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function toast(m){const t=$('toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2500)}
async function api(url,opts={}){const r=await fetch(url,{headers:{'Content-Type':'application/json'},...opts});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.message||'Request failed');return d}
function logout(){localStorage.removeItem('ticketlyUser');location.href='/login.html'}
async function refresh(){
 try{
  const [events,bookings]=await Promise.all([api('/api/events'),api('/api/admin/bookings')]);
  $('adminEvents').innerHTML=events.length?events.map(e=>`<div class="admin-event-row"><div><strong>${safe(e.title)}</strong><small>${safe(e.eventDate)} · ₹${Number(e.price).toLocaleString('en-IN')} · ${e.availableSeats} seats</small></div><button class="danger" onclick="deleteEvent(${e.id})">Delete</button></div>`).join(''):'<p class="muted">No events published.</p>';
  $('allBookings').innerHTML=bookings.length?bookings.map(b=>`<div class="admin-event-row"><div><strong>${safe(b.eventTitle)}</strong><small>${safe(b.bookingCode)} · ${b.quantity} ticket(s) · ₹${Number(b.totalPrice).toLocaleString('en-IN')}</small></div><span class="status">${safe(b.status)}</span></div>`).join(''):'<p class="muted">No bookings yet.</p>';
 }catch(e){$('adminEvents').innerHTML='<p class="muted">Could not load data. Check database connection.</p>'}
}
$('eventForm').addEventListener('submit',async e=>{
 e.preventDefault();const f=new FormData(e.target);const body=Object.fromEntries(f.entries());body.price=Number(body.price);body.availableSeats=Number(body.availableSeats);
 try{await api('/api/admin/events',{method:'POST',body:JSON.stringify(body)});$('adminMessage').textContent='Event published!';$('adminMessage').style.color='#247340';e.target.reset();refresh();toast('Event published successfully')}
 catch(err){$('adminMessage').textContent=err.message}
});
async function deleteEvent(id){if(!confirm('Delete this event? Events with bookings may not be deletable.'))return;try{await api('/api/admin/events/'+id,{method:'DELETE'});toast('Event deleted');refresh()}catch(e){toast(e.message)}}
document.addEventListener('DOMContentLoaded',()=>{const u=JSON.parse(localStorage.getItem('ticketlyUser')||'null');if(!u||u.role!=='ADMIN'){document.querySelector('.admin-wrap').innerHTML='<section class="panel"><h2>Admin login required</h2><p class="muted">Sign in with an ADMIN account to use this dashboard.</p><a class="primary" href="/login.html">Go to login →</a></section>';return}refresh()});
