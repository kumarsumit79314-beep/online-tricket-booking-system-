CREATE DATABASE IF NOT EXISTS ticket_booking;
USE ticket_booking;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'USER',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS events (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(150) NOT NULL,
  category VARCHAR(60) NOT NULL,
  venue VARCHAR(150) NOT NULL,
  event_date DATE NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  available_seats INT NOT NULL DEFAULT 0,
  description VARCHAR(500)
);

CREATE TABLE IF NOT EXISTS bookings (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  event_id BIGINT NOT NULL,
  quantity INT NOT NULL,
  total_price DECIMAL(10,2) NOT NULL,
  booking_code VARCHAR(40) NOT NULL UNIQUE,
  status VARCHAR(20) NOT NULL DEFAULT 'CONFIRMED',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_booking_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_booking_event FOREIGN KEY (event_id) REFERENCES events(id)
);

INSERT INTO events(title, category, venue, event_date, price, available_seats, description)
SELECT 'Live Music Night', 'Music', 'City Arena', '2027-01-20', 799.00, 150, 'An evening of live music and entertainment.'
WHERE NOT EXISTS (SELECT 1 FROM events WHERE title='Live Music Night');
INSERT INTO events(title, category, venue, event_date, price, available_seats, description)
SELECT 'Tech Innovators Conference', 'Conference', 'Expo Centre', '2027-02-14', 1299.00, 100, 'Meet builders, developers and technology leaders.'
WHERE NOT EXISTS (SELECT 1 FROM events WHERE title='Tech Innovators Conference');
INSERT INTO events(title, category, venue, event_date, price, available_seats, description)
SELECT 'Comedy Show', 'Comedy', 'Downtown Theatre', '2027-03-08', 499.00, 80, 'A fun night with stand-up comedians.'
WHERE NOT EXISTS (SELECT 1 FROM events WHERE title='Comedy Show');
