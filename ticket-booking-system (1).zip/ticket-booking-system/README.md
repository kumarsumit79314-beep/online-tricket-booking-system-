# Ticketly — Java + JDBC + MySQL ticket booking project

A college-project starter containing a public event listing page, login/register page, booking flow, user booking history and admin dashboard.

## Tech stack
- Java 17, Spring Boot REST API
- MySQL database and JDBC (`JdbcTemplate`)
- HTML, CSS and JavaScript frontend
- BCrypt password hashing

## 1. Install prerequisites
1. Install **JDK 17 or newer**.
2. Install **MySQL Server** and MySQL Workbench (Workbench is optional).
3. Install **Maven** (or use IntelliJ IDEA with Maven support).
4. Install VS Code or IntelliJ IDEA.

Verify in Command Prompt:
```bash
java -version
mvn -version
```

## 2. Create the database
1. Open MySQL Workbench and connect to your local MySQL server.
2. Open `database.sql` from this project.
3. Run the complete script. It creates `ticket_booking`, tables and three sample events.

## 3. Configure database password
Open `src/main/resources/application.properties` and replace:
```properties
spring.datasource.password=YOUR_MYSQL_PASSWORD
```
with your local MySQL password. Keep username `root` only if that is your actual MySQL user. Do not upload real credentials to public Git repositories.

## 4. Start the website
Open a terminal in the project folder and run:
```bash
mvn spring-boot:run
```
Wait until Spring Boot reports that it has started, then open:
- Website: http://localhost:8080/
- Login/register: http://localhost:8080/login.html
- Admin panel: http://localhost:8080/admin.html

The frontend and backend are served by the same Java app, so do not double-click the HTML files. Open them through `http://localhost:8080`.

## 5. Create an admin account
1. Open `http://localhost:8080/login.html`.
2. Create a normal account.
3. In MySQL Workbench run this query, replacing the email with the account email you registered:
```sql
USE ticket_booking;
UPDATE users SET role='ADMIN' WHERE email='your-email@example.com';
```
4. Log out if needed, sign in again, then open `http://localhost:8080/admin.html`.

The demo frontend stores the signed-in user's basic profile in browser local storage. **This is an educational demo, not production-ready authentication.** The admin endpoints are not protected by a server-side session/token in this starter, so add Spring Security authentication and server-side role checks before deployment. Never deploy this demo publicly as-is.

## Included OOP / Java concepts
- **Interface:** `BookingOperations`
- **Polymorphism:** controller depends on `BookingOperations`; Spring injects `StandardBookingService`
- **Inheritance:** `BookingException extends RuntimeException`
- **Exception handling:** validation exceptions and REST error responses
- **Collections & Generics:** `List<Event>`, `List<Booking>`, `Optional<User>`, `Map<String,Object>`
- **Multithreading & synchronization:** Spring can handle concurrent HTTP requests; `synchronized` booking service method and SQL `FOR UPDATE` row lock help serialize seat changes
- **Database operation classes:** `UserRepository`, `EventRepository`, `BookingRepository`
- **JDBC:** `JdbcTemplate` prepared parameter queries, inserts and updates; `@Transactional` booking operation

## Useful API endpoints
- `GET /api/events`
- `POST /api/register` body: `{"name":"Alex","email":"alex@example.com","password":"secret123"}`
- `POST /api/login` body: `{"email":"alex@example.com","password":"secret123"}`
- `POST /api/bookings` body: `{"userId":1,"eventId":1,"quantity":2}`
- `GET /api/users/1/bookings`
- `GET /api/admin/bookings`
- `POST /api/admin/events`
- `DELETE /api/admin/events/1`

## Troubleshooting
- **Access denied for user:** check MySQL username/password in `application.properties`.
- **Unknown database:** run `database.sql` in MySQL Workbench.
- **Port 8080 in use:** change `server.port=8080` to another free port.
- **mvn not recognized:** install Maven or open the project in IntelliJ and run the Maven `spring-boot:run` goal.
- **No events shown:** confirm MySQL is running and the SQL script completed successfully.
